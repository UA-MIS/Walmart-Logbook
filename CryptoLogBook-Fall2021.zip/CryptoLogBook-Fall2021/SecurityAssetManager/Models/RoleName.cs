﻿namespace SecurityAssetManager.Models
{
    public static class RoleName
    {
        public const string Admin = "Admin";
        public const string Witness = "Witness";
        public const string Keyholder = "Keyholder";
        public const string Auditor = "Auditor";
    }
}